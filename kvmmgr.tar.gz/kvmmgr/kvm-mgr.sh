#!/bin/sh
if [ "${1}" = "version" ]; then
  echo "kvm-mgr version 1.0"
  exit 0
elif [ "${1}" = "help" ]; then
  echo "*******************************************************************"
  echo "kvm-mgr [package|version|help]"
  echo "   package : create a .tar.gz archive of the current version"
  echo "   version : show the current version of the package"
  echo "   help : display command help"
  echo ""
  echo "kvm-mgr [start|stop|freeze|awake|status] vmname"
  echo "   start : start the selected vm"
  echo "   stop : stop the selected vm"
  echo "   freeze : freeze the selected vm"
  echo "   awake : awake a frozen vm"
  echo "   status : display the vm current status (up, down, frozen)"
  echo "*******************************************************************"
  exit 0
elif [ "${1}" = "package" ]; then
	mkdir ~/kvm-mgr/kvmmgr > /dev/null
	cp ~/kvm-mgr/kvm-mgr.sh ~/kvm-mgr/kvmmgr/ > /dev/null
	cp ~/kvm-mgr/status.bash ~/kvm-mgr/kvmmgr/ > /dev/null
	mkdir ~/kvm-mgr/kvmmgr/vm/ > /dev/null
	echo "IPmachine=localhost						#Machine hébergeant la VM
IPvm=10.0.0.1							#IP de la VM
usernamemachine=root					#user de la machine hébergeant la VM
usernamevm=user							#user de la VM
MAC=42:30:03:ff:ff:fe					#@ MAC de la VM
porttcp=4444							#Port d'externalisation du moniteur qemu
socketreseau=/var/run/vde2/kvmtap0.ctl	#Chemin du socket reseau
status=down 							#Status de la VM (par défaut down)" >> ~/kvm-mgr/kvmmgr/vm/vm.conf.example
	cd ~/kvm-mgr
	tar czf kvmmgr.tar.gz kvmmgr > /dev/null
	rm -r kvmmgr > /dev/null
	cd ~
	echo "DONE !"
	echo "You can also find this package on the official GitHub repository."
	echo "https://github.com/KVMmgr/kvm-mgr"
	exit 0
  fi

  vm=${2}
  if [ ! -f "vm/$vm.conf" ]; then
	echo "Configuration file of $vm does not exist"
	exit 1
  fi
  IPmachine=`cat ~/vm/$vm.conf | grep IPmachine | cut -d '=' -f2`
  IPvm=`cat ~/vm/$vm.conf | grep IPvm | cut -d '=' -f2`
  usernamemachine=`cat ~/vm/$vm.conf | grep usernamemachine | cut -d '=' -f2`
  usernamevm=`cat ~/vm/$vm.conf | grep usernamevm | cut -d '=' -f2`
  MAC=`cat ~/vm/$vm.conf | grep MAC | cut -d '=' -f2`
  portmoniteur=`cat ~/vm/$vm.conf | grep porttcp | cut -d '=' -f2`
  socket=`cat ~/vm/$vm.conf | grep socket | cut -d '=' -f2`
  status=`cat ~/vm/$vm.conf | grep status | cut -d '=' -f2`

  if [ "${1}" = "start" ]; then
    ssh -f $usernamemachine@$IPmachine 'DISPLAY=:0 xterm -e 'kvm -m 4G -hda `echo $vm`.qcow2 -net nic,macaddr=$MAC -net vde,sock=$socket -monitor tcp::$portmoniteur,server,nowait -serial mon:stdio; $SHELL'&'
	sed -i 's/down/up/g' vm/$vm.conf
	echo "Starting $vm"
  elif [ "${1}" = "stop" ]; then
    ssh -f $usernamemachine@$IPmachine 'DISPLAY=:0 xterm -e "ssh '$usernamevm'@'$IPvm' 'sudo halt -p'; exit ; $SHELL"&'
	sed -i 's/up/down/g' vm/$vm.conf
	echo "Stopping $vm"
  elif [ "${1}" = "freeze" ]; then
    ssh $usernamemachine@$IPmachine 'echo stop >/dev/tcp/127.0.0.1/'$portmoniteur''
	sed -i 's/up/frozen/g' vm/$vm.conf
	echo "$vm frozen"
  elif [ "${1}" = "awake" ]; then
    ssh $usernamemachine@$IPmachine 'echo c >/dev/tcp/127.0.0.1/'$portmoniteur''
	sed -i 's/frozen/up/g' vm/$vm.conf
	echo "$vm awakened"
  elif [ "${1}" = "status" ]; then
	if [ "$status" != "up" ]; then
		echo "$vm is $status"
	elif [ "$status" = "up" ]; then
    	scp status.bash $usernamemachine@$IPmachine: > /dev/null
    	ssh $usernamemachine@$IPmachine "scp status.bash '$usernamevm'@'$IPvm':" > /dev/null
    	ssh $usernamemachine@$IPmachine "ssh '$usernamevm'@'$IPvm' 'sudo ./status.bash'"
    	ssh $usernamemachine@$IPmachine "ssh '$usernamevm'@'$IPvm' 'sudo rm -r status.bash'"
    	ssh $usernamemachine@$IPmachine "rm -r status.bash"
	fi
  fi
  exit 0
