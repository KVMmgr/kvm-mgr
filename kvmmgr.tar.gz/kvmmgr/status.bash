#!/bin/bash 

echo
echo
echo %%%%%%%%%%%%%%% Serveur $(hostname) %%%%%%%%%%%%%%%
echo

echo --------------------------
echo Nous sommes $(date |cut -d ',' -f1) 
echo Il est $(date |cut -d ',' -f2|cut -d '(' -f1)
echo

echo $(hostname) fonctionne depuis \:
echo
echo $(uptime -p | awk '{print $2" "$3}'|cut -d ',' -f1)
echo $(uptime -p | awk '{print $4" "$5}') 
echo $(uptime -p | awk '{print $6" "$7}') 

echo --------------------------
echo Processeurs \:
echo

val=$(top -b -n1 | grep %Cpu | awk '{print $8;}')
let val=(100-$val)

if (($val<100)) 
then
echo "Ulitisation     : $val"%""
else
echo "Ulitisation     : $val"%"               SURCHAUFFE !!"
fi

echo "$(cat /proc/cpuinfo |grep cpu| tail -n 5 | head -n 2)"
echo "$(cat /proc/cpuinfo | grep model | cut -c14- | tail -n 1)"
echo

echo --------------------------
echo "Memoire" \:
echo
echo "Memoire Totale    : $(free -h |grep Mem | awk '{print $2;}')"
echo "Memoire Utilisee  : $(free -h |grep Mem | awk '{print $3;}')"
echo "Memoire Libre     : $(free -h |grep Mem | awk '{print $4;}')"
echo

echo
echo Espace disque \:
echo 
echo "Partition : $(df -h / | tail -n1 | awk '{print $1;}')"
echo
echo "Utilise   : $(df -h / | tail -n1 | awk '{print $3;}')"
echo "Libre     : $(df -h / | tail -n1 | awk '{print $4;}')"
echo "Total     : $(df -h / | tail -n1 | awk '{print $2;}')"
echo

echo --------------------------
echo "Processus" \:
echo
echo "Actif(s)   $(top -b -n1 | head -n2 |tail -n1 | awk {'print $4'})"
echo "Endormi(s) $(top -b -n1 | head -n2 |tail -n1 | awk {'print $6'})"
echo "Arrete(s)  $(top -b -n1 | head -n2 |tail -n1 | awk {'print $8'})"
echo "Zombie(s)  $(top -b -n1 | head -n2 |tail -n1 | awk {'print $10'})"
echo "Total      $(top -b -n1 | head -n2 |tail -n1 | awk {'print $2'})"
echo

echo --------------------------
echo Service HTTP \:
echo "$(sudo service apache2 status | grep Active)"
echo
echo --------------------------


echo
echo %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo

exit 0


